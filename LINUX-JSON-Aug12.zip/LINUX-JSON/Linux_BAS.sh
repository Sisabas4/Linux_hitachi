#!/bin/bash

show_banner() {
cat << "EOF"
 __  __       _       __  __                  
|  \/  | __ _(_)_ __ |  \/  | ___ _ __  _   _ 
| |\/| |/ _` | | '_ \| |\/| |/ _ \ '_ \| | | |
| |  | | (_| | | | | | |  | |  __/ | | | |_| |
|_|  |_|\__,_|_|_| |_|_|  |_|\___|_| |_|\__,_|
        Placeholder Security Framework

EOF
}

declare -A TACTIC_MAP=(
    ["1"]="Precheck"
    ["2"]="Discovery"
    ["3"]="Execution"
    ["4"]="Defense_Evasion"
    ["5"]="Persistence"
    ["6"]="Privilege_Escalation"
    ["7"]="Collection"
    ["8"]="Impact"
    ["9"]="Exfiltration"
    ["10"]="Cleanup"
    ["11"]="Summary_Report"
)

while true; do
    clear
    show_banner

    echo "============== Main Menu =============="
    for i in $(seq 1 11); do
        echo "[$i] ${TACTIC_MAP[$i]}"
    done
    echo "[0] Exit"
    echo "======================================="
    read -p "Enter your choice: " choice

    if [[ "$choice" == "0" ]]; then
        echo "Exiting!"
        exit 0
    fi

    tactic=${TACTIC_MAP[$choice]}

    if [[ -z "$tactic" ]]; then
        echo "Invalid choice."
        sleep 1
        continue
    fi

    if [[ "$tactic" == "Precheck" ]]; then
        # Just run precheck.sh directly (no JSON)
        if [[ -x "./Precheck.sh" ]]; then
            ./Precheck.sh
        elif [[ -f "./Precheck.sh" ]]; then
            bash ./Precheck.sh
        else
            echo "Precheck script not found!"
        fi
    elif [[ "$tactic" == "Summary_Report" ]]; then
        script="summaryreport.sh"
        if [[ -x ./$script ]]; then
            ./$script
        elif [[ -f ./$script ]]; then
            bash ./$script
        else
            echo "Summary Report script not found!"
        fi
    elif [[ "$tactic" == "Cleanup" ]]; then
        script="Cleanup.sh"
        if [[ -x ./$script ]]; then
            ./$script
        elif [[ -f ./$script ]]; then
            bash ./$script
        else
            echo "Cleanup script not found!"
        fi    
    else
        # Load OS info
        if [[ -f Config/os_detected.env ]]; then
            . Config/os_detected.env
        else
            echo "OS detection file missing! Please run Precheck first."
            read -p "Press Enter to return to menu..."
            continue
        fi

        # Determine OS family suffix for JSON file naming
        case "$OS_ID" in
            ubuntu|debian|kali)
                os_suffix="Deb"
                ;;
            rhel|centos|amzn|fedora)
                os_suffix="RHEL"
                ;;
            *)
                echo "Unsupported or unknown OS: $OS_ID"
                read -p "Press Enter to return to menu..."
                continue
                ;;
        esac

        # Compose JSON filename, e.g. Config/Discovery_Deb.json
        json_file="Config/${tactic}_${os_suffix}.json"

        # Check if JSON exists before calling loader
        if [[ -f "$json_file" ]]; then
            script="Loader.sh"
            if [[ -x "./$script" ]]; then
                ./"$script" "$json_file"
            elif [[ -f "./$script" ]]; then
                bash "./$script" "$json_file"
            else
                echo "Loader script not found!"
            fi
        else
            echo "Config JSON file not found for tactic '$tactic' at $json_file"
        fi
    fi

    echo
    read -p "Press Enter to return to menu..."
done

