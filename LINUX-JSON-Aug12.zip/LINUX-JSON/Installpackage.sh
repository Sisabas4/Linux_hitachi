#!/bin/bash

# ==========================
#  Installpackage.sh Script
#  (Requires Precheck to be run first)
# ==========================

# ---- Colors for terminal only ----
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
RED="\033[1;31m"
NC="\033[0m" # No Color

# ---- Load OS info from precheck ----
if [ -f Config/os_detected.env ]; then
    . Config/os_detected.env
else
    echo -e "${RED}ERROR: OS detection file missing. Please run precheck first.${NC}"
    exit 1
fi

PACKAGE_FILE="Config/packages.txt"
MISSING=()
STATUS=()
ERROR_LOGS=()
INSTALLED_COUNT=0
FAILED_COUNT=0

# ---- Ensure output folders exist ----
OUTPUT_ERROR_PATH="Output/Precheck"
CLEANUP_PRECHECK_DIR="Cleanup/Precheck"
mkdir -p "$OUTPUT_ERROR_PATH"
mkdir -p "$CLEANUP_PRECHECK_DIR"

OUTPUT_FILE="$CLEANUP_PRECHECK_DIR/Touninstall.txt"

# ---- Choose Package Manager ----
case "$OS_ID" in
    ubuntu|debian|kali)
        PKG_UPDATE="apt update -qq"
        PKG_INSTALL="apt install -y"
        PMAN="apt"
        ;;
    amzn|rhel|centos|fedora)
        if command -v dnf &>/dev/null; then
            PKG_UPDATE="dnf makecache"
            PKG_INSTALL="dnf install -y"
            PMAN="dnf"
        else
            PKG_UPDATE="yum makecache"
            PKG_INSTALL="yum install -y"
            PMAN="yum"
        fi
        ;;
    *)
        echo -e "${RED}ERROR: Unsupported or unknown OS: $OS_ID${NC}"
        exit 1
esac

# ---- Normalize OS name to header in packages.txt ----
case "$OS_ID" in
    ubuntu|debian) TARGET_OS="Ubuntu" ;;
    rhel)          TARGET_OS="RHEL" ;;
    centos)        TARGET_OS="CentOS" ;;
    kali)          TARGET_OS="Kali" ;;
    # Extend mapping here if needed
    *) echo -e "${RED}OS $OS_ID not mapped. Aborting.${NC}"; exit 1 ;;
esac

# ---- Parse header to find column index ----
OS_HEADER=$(awk 'NR==2 {print; exit}' "$PACKAGE_FILE")
IFS=',' read -ra OS_COLUMNS <<< "$OS_HEADER"
OS_COL_IDX=-1
for idx in "${!OS_COLUMNS[@]}"; do
    if [[ "${OS_COLUMNS[$idx]// /}" == "$TARGET_OS" ]]; then
        OS_COL_IDX=$idx
        break
    fi
done
if [ "$OS_COL_IDX" -lt 0 ]; then
    echo -e "${RED}Could not find column for $TARGET_OS in $PACKAGE_FILE${NC}"
    exit 1
fi

# ---- Header ----
echo -e "\n${YELLOW}[+] Checking Required Packages for $OS_ID ($OS_VERSION)...${NC}\n"
printf "%-20s | %-18s\n" "Package" "Status"
printf "%-20s | %-18s\n" "Package" "Status" > "$OUTPUT_FILE"
echo "---------------------------------------------"
echo "---------------------------------------------" >> "$OUTPUT_FILE"

# ---- Determine where package data starts ----
DATA_START_LINE=$(( $(awk '/^Ubuntu,|^Fedora,|^CentOS,|^Kali,|^RHEL,|^AmazonLinux/ {print NR; exit}' "$PACKAGE_FILE") + 1 ))

# ---- Find Packages for this OS (avoid piped while!) ----
awk "NR>=$DATA_START_LINE && !/^#/" "$PACKAGE_FILE" > /tmp/pkgs_to_install.$$
while IFS=',' read -ra fields; do
    PKG="${fields[$OS_COL_IDX]}"
    PKG="$(echo "$PKG" | xargs)"   # Trim whitespace
    [ -z "$PKG" ] && continue

    PKG_INSTALLED=0
    if command -v "$PKG" >/dev/null 2>&1; then
        PKG_INSTALLED=1
    elif [[ "$PMAN" == "apt" ]] && dpkg -s "$PKG" 2>/dev/null | grep -q '^Status:.*installed$'; then
        PKG_INSTALLED=1
    elif [[ "$PMAN" =~ yum|dnf ]] && rpm -q "$PKG" &>/dev/null; then
        PKG_INSTALLED=1
    fi

    if [[ $PKG_INSTALLED -eq 1 ]]; then
        printf "%-20s | ${GREEN}%-18s${NC}\n" "$PKG" "Already Installed"
        printf "%-20s | %-18s\n" "$PKG" "Already Installed" >> "$OUTPUT_FILE"
        STATUS+=("$PKG:Already Installed")
    else
        printf "%-20s | ${YELLOW}%-18s${NC}\n" "$PKG" "Not Installed"
        printf "%-20s | %-18s\n" "$PKG" "Not Installed" >> "$OUTPUT_FILE"
        MISSING+=("$PKG")
        STATUS+=("$PKG:Not Installed")
    fi
done < /tmp/pkgs_to_install.$$
rm -f /tmp/pkgs_to_install.$$

TOTAL=${#STATUS[@]}

# ---- Ensure EPEL on RHEL/CentOS ----
if [[ "$OS_ID" == "rhel" || "$OS_ID" == "centos" ]]; then
    if ! rpm -q epel-release >/dev/null 2>&1; then
        echo -e "${YELLOW}[+] Installing epel-release (required for extra packages)...${NC}"
        sudo $PKG_INSTALL epel-release
    fi
fi

# ---- Install missing packages ----
if [ ${#MISSING[@]} -ne 0 ]; then
    echo -e "\n${YELLOW}[+] Some packages are missing.${NC}"
    read -p "[!] Do you want to install them? (y/n): " choice
    if [[ "$choice" =~ ^[Yy]$ ]]; then
        echo -e "\n${YELLOW}[!] Installing missing packages using '$PMAN'...${NC}\n"
        sudo $PKG_UPDATE
        for pkg in "${MISSING[@]}"; do
            echo -e "${YELLOW}[+] Installing Package : $pkg${NC}"
            ERR_FILE="$OUTPUT_ERROR_PATH/install_fail_${pkg}_$(date +%Y%m%d_%H%M%S).log"
            if sudo $PKG_INSTALL "$pkg" > /dev/null 2> "$ERR_FILE"; then
                STATUS=("${STATUS[@]/$pkg:Not Installed/$pkg:Installed}")
                ((INSTALLED_COUNT++))
                printf "%-20s | ${GREEN}%-18s${NC}\n" "$pkg" "Installed"
                printf "%-20s | %-18s\n" "$pkg" "Installed" >> "$OUTPUT_FILE"
                rm -f "$ERR_FILE"
            else
                STATUS=("${STATUS[@]/$pkg:Not Installed/$pkg:Failed}")
                ERROR_LOGS+=("$ERR_FILE")
                ((FAILED_COUNT++))
                printf "%-20s | ${RED}%-18s${NC}\n" "$pkg" "Failed (See $ERR_FILE)"
                printf "%-20s | %-18s\n" "$pkg" "Failed (See $ERR_FILE)" >> "$OUTPUT_FILE"
            fi
        done
    else
        echo -e "${RED}Installation aborted by user.${NC}"
        echo "Installation aborted by user." >> "$OUTPUT_FILE"
    fi
fi

# ---- Print summary to terminal and file (plain) ----
echo -e "\n${YELLOW}Installation Summary:${NC}"
echo "---------------------------------------------"
printf "%-20s | %-18s\n" "Package" "Final Status"
echo "---------------------------------------------"

echo "---------------------------------------------" >> "$OUTPUT_FILE"
printf "%-20s | %-18s\n" "Package" "Final Status" >> "$OUTPUT_FILE"
echo "---------------------------------------------" >> "$OUTPUT_FILE"

for entry in "${STATUS[@]}"; do
    pkg="${entry%%:*}"
    status="${entry##*:}"
    case "$status" in
        "Installed"|"Already Installed") COLOR="$GREEN";;
        "Failed"*) COLOR="$RED";;
        *) COLOR="$YELLOW";;
    esac
    printf "%-20s | ${COLOR}%-18s${NC}\n" "$pkg" "$status"
    printf "%-20s | %-18s\n" "$pkg" "$status" >> "$OUTPUT_FILE"
done
echo "---------------------------------------------"
echo "---------------------------------------------" >> "$OUTPUT_FILE"

echo -e "Total Packages   : $TOTAL"
echo -e "Installed Now    : $INSTALLED_COUNT"
echo -e "Already Installed: $((TOTAL - INSTALLED_COUNT - FAILED_COUNT))"
echo -e "Failed Installs  : $FAILED_COUNT"
echo -e "Total Packages   : $TOTAL" >> "$OUTPUT_FILE"
echo -e "Installed Now    : $INSTALLED_COUNT" >> "$OUTPUT_FILE"
echo -e "Already Installed: $((TOTAL - INSTALLED_COUNT - FAILED_COUNT))" >> "$OUTPUT_FILE"
echo -e "Failed Installs  : $FAILED_COUNT" >> "$OUTPUT_FILE"

if [ $FAILED_COUNT -ne 0 ]; then
    echo -e "${RED}Error details for failed installs are saved as:${NC}"
    for err in "${ERROR_LOGS[@]}"; do
        echo "    $err"
    done
fi
echo

