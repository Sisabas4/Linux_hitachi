#!/bin/bash

# ===========================================================================================
#
#  Precheck Script  = To check Prerequisites and continue to main script or stop execution
#
# ===========================================================================================
# Create output dir if needed
PRECHECK_OUTDIR="Output/Precheck"
mkdir -p "$PRECHECK_OUTDIR"

# ==== 0. Check for Admin Privilege ====
if [[ "$(id -u)" -ne 0 ]]; then
    echo "[!] Admin (root) access is required for simulation. Please run as root or with sudo."
    exit 1
fi

# ==== 1. Check Folder Structure ====
ROOT=$(dirname "$(readlink -f "$0")")
echo "DEBUG: ROOT=${ROOT}"
for dir in Config Template Output SummaryReport Cleanup; do
    if [[ ! -d "$ROOT/$dir" ]]; then
        echo "ERROR: Required folder '$dir' does not exist in project root ($ROOT)."
        exit 1
    fi
done

# ==== 2. Check Network Connectivity ====
if ping -c 1 -W 2 8.8.8.8 >/dev/null 2>&1; then
    NET_RESULT="UP"
else
    NET_RESULT="DOWN"
fi

# ==== 3. Collect Basic Info ====

# OS Type
OS_NAME=""
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_NAME=$ID
    OS_VERSION=$VERSION_ID
else
    OS_NAME=$(uname -s)
    OS_VERSION=$(uname -r)
fi

case "$OS_NAME" in
    rhel|centos|fedora) COMPAT_OS="RHEL/CentOS/Fedora";;
    ubuntu|debian)      COMPAT_OS="Ubuntu/Debian";;
    kali)               COMPAT_OS="Kali";;
    amzn)               COMPAT_OS="AmazonLinux";;
    *)                  COMPAT_OS="Other/Unknown";;
esac

# IP, Hostname, Hardware, Time
IP=$(hostname -I 2>/dev/null | awk '{for(i=1;i<=NF;i++) if ($i != "127.0.0.1") {print $i; exit}}')
[ -z "$IP" ] && IP=$(hostname -i 2>/dev/null)
HOST=$(hostname)
CPU=$(awk -F: '/model name/ {name=$2} END {print name}' /proc/cpuinfo | sed 's/^ //')
CORES=$(grep -c '^processor' /proc/cpuinfo)
MEM=$(free -h | awk '/Mem:/ {print $2}')
DISK=$(df -h / | awk 'NR==2 {print $2 " total, " $4 " free"}')
SYS_TIME=$(date)
TIMEZONE=$(date +%Z)

# ==== 4. Save OS info to Config/os_detected.env (silent) ====
cat > "$ROOT/Config/os_detected.env" <<EOF
OS_ID=$OS_NAME
OS_VERSION=$OS_VERSION
COMPAT_OS="$COMPAT_OS"
EOF

# ==== 5. Create Sputnik user (admin) and Titan user (non-admin), check privileges (silent) ====

# Function to create user if missing, with bash shell
create_user_if_missing() {
    local uname="$1"
    if ! id "$uname" &>/dev/null; then
        useradd -m -s /bin/bash "$uname" &>/dev/null
        echo "$uname:sputnikTitan" | chpasswd &>/dev/null
    else
        # If the user exists, ensure default shell is bash
        chsh -s /bin/bash "$uname" &>/dev/null
    fi
}

# Sputnik - admin user
ADMIN_GROUP=""
ADMIN_STATUS="NO"
create_user_if_missing "Sputnik"

case "$OS_NAME" in
    ubuntu|debian|kali)
        ADMIN_GROUP="sudo"
        usermod -aG sudo Sputnik &>/dev/null
        ;;
    rhel|centos|amzn|fedora)
        ADMIN_GROUP="wheel"
        usermod -aG wheel Sputnik &>/dev/null
        ;;
    *)
        ADMIN_GROUP=""
        ;;
esac

if [ -n "$ADMIN_GROUP" ] && id Sputnik | grep -qE "($ADMIN_GROUP)"; then
    ADMIN_STATUS="YES"
fi

# Titan - normal user, no admin
create_user_if_missing "Titan"
# Remove Titan from admin group (cross-distro)
if [[ "$OS_NAME" == "ubuntu" || "$OS_NAME" == "debian" || "$OS_NAME" == "kali" ]]; then
    deluser Titan sudo &>/dev/null
elif [[ "$OS_NAME" == "rhel" || "$OS_NAME" == "centos" || "$OS_NAME" == "amzn" || "$OS_NAME" == "fedora" ]]; then
    gpasswd -d Titan wheel &>/dev/null
fi

TITAN_ADMIN_STATUS="NO"
if [ -n "$ADMIN_GROUP" ] && id Titan | grep -qE "($ADMIN_GROUP)"; then
    TITAN_ADMIN_STATUS="YES"
fi


# ==== 6. Audit Check for whoami ====

WHOAMI_TIME=$(date +"%m/%d/%Y %H:%M:%S")
WHOAMI_USER=$(whoami)

#AUDIT_LOG_FILE="$ROOT/Output/audit_whoami.log"
AUDIT_LOG_FILE="$PRECHECK_OUTDIR/audit_whoami.log"
RAW_AUSEARCH_OUTPUT=$(
    ausearch -k exec_monitor -i 2>/dev/null \
    | grep '^type=EXECVE' \
    | grep 'a0=whoami' \
    | grep -v 'a0=grep' \
    | tail -1
)

if [[ -z "$RAW_AUSEARCH_OUTPUT" ]]; then
    AUDIT_MATCH="NO"
    AUDIT_LOG_TIME="N/A"
    # Log failure if you wish; recommended to write only on success as you request
    LOCAL_LOG_MSG="NOT capturing or TIME MISMATCH! See log file: $AUDIT_LOG_FILE"
else
    AUDIT_LOG_TIME=$(echo "$RAW_AUSEARCH_OUTPUT" | sed -n 's/.*audit(\(.*\):[0-9][0-9]*).*/\1/p' | cut -d. -f1)
    audit_epoch=$(date -d "$AUDIT_LOG_TIME" +%s)
    whoami_epoch=$(date -d "$WHOAMI_TIME" +%s)
    TIME_DIFF=$(( audit_epoch - whoami_epoch ))
    if (( TIME_DIFF >= -2 && TIME_DIFF <= 2 )); then
        AUDIT_MATCH="YES"
        LOCAL_LOG_MSG="Local log is available and capturing"
        {
          echo "Executing whoami as $WHOAMI_USER at $WHOAMI_TIME"
          echo "[+] Auditd EXECVE log for 'whoami': $AUDIT_LOG_TIME"
          echo
          echo "------ RAW ausearch LOG ------"
          echo "$RAW_AUSEARCH_OUTPUT"
          echo "-----------------------------"
          echo "[Audit Check] whoami run-time: $WHOAMI_TIME | audit log time: $AUDIT_LOG_TIME"
          echo "[+] Audit log and execution time match (logging is working)"
        } > "$AUDIT_LOG_FILE"
    else
        AUDIT_MATCH="TIME MISMATCH"
        LOCAL_LOG_MSG="NOT capturing or TIME MISMATCH! See log file: $AUDIT_LOG_FILE"
        {
          echo "Executing whoami as $WHOAMI_USER at $WHOAMI_TIME"
          echo "[+] Auditd EXECVE log for 'whoami': $AUDIT_LOG_TIME"
          echo
          echo "------ RAW ausearch LOG ------"
          echo "$RAW_AUSEARCH_OUTPUT"
          echo "-----------------------------"
          echo "[Audit Check] whoami run-time: $WHOAMI_TIME | audit log time: $AUDIT_LOG_TIME"
          echo "[!] Audit log missing or time mismatch (check auditd rules)"
        } > "$AUDIT_LOG_FILE"
    fi
fi

if [[ "$AUDIT_MATCH" != "YES" ]]; then
    # Show colored log output and set message for summary
    RED="\033[1;31m"
    GREEN="\033[1;32m"
    NC="\033[0m"
    sed -e "s/\(\[\+]\)/${GREEN}\1${NC}/g" \
        -e "s/\(\[!]\)/${RED}\1${NC}/g" \
        "$AUDIT_LOG_FILE"
    LOCAL_LOG_MSG="NOT capturing or TIME MISMATCH! See log file: $AUDIT_LOG_FILE"
else
    LOCAL_LOG_MSG="Local log is available and capturing"
fi

# ==== 7. Check for EDR Presence ====

EDR_HINTS=$(ps aux | grep -E 'falcon|cbdaemon|sentinel|savd|ds_agent|mdatp' | grep -v grep)
EDR_FOLDERS=$(ls /opt/ /etc/ 2>/dev/null | grep -Ei 'falcon|carbonblack|sentinel|sophos|mcafee|eset|trend|defender')

if [[ -n "$EDR_HINTS" || -n "$EDR_FOLDERS" ]]; then
    EDR_STATUS="Potential EDR presence detected"
    EDR_DETAIL="$EDR_HINTS"$'\n'"$EDR_FOLDERS"
    # Optionally save detailed info for reference (timestamped log)
    # EDR_DETAIL_LOG="Output/edr_detect_$(date +%Y%m%d_%H%M%S).log"
    # EDR_DETAIL_LOG="$PRECHECK_OUTDIR/edr_detect_$(date +%Y%m%d_%H%M%S).log"
    {
        echo "====== Possible EDR agent processes ======"
        echo "$EDR_HINTS"
        echo
        echo "====== Possible EDR agent folders ========"
        echo "$EDR_FOLDERS"
    } > "$EDR_DETAIL_LOG"
    EDR_DETAIL_MSG=": See $EDR_DETAIL_LOG"
else
    EDR_STATUS="No common EDR detected"
    EDR_DETAIL=""
    EDR_DETAIL_MSG=""
fi


# ====  Output ====

# Define colors
YELLOW="\033[1;33m"
GREEN="\033[1;32m"
NC="\033[0m" # No Color

echo -e "${YELLOW}========= Precheck Results ============================${NC}"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Required folders exist." "[OK]"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Network Connectivity" "$NET_RESULT"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "OS Detected" "$OS_NAME ($OS_VERSION)"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Compatible Target" "$COMPAT_OS"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Hostname" "$HOST"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "IP address" "$IP"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "CPU Model" "$CPU"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "CPU Cores" "$CORES"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "RAM" "$MEM"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Disk" "$DISK"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "System Time" "$SYS_TIME"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Timezone" "$TIMEZONE"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Admin access for Sputnik" "$ADMIN_STATUS"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Admin access for Titan" "$TITAN_ADMIN_STATUS"
printf "${YELLOW}%-30s:${GREEN} %s${NC}\n" "Local Log" "$LOCAL_LOG_MSG"
printf "${YELLOW}%-30s:${GREEN} %s%s${NC}\n" "EDR Detection" "$EDR_STATUS" "$EDR_DETAIL_MSG"
echo -e "${YELLOW}====================================================${NC}"

# Save summary to plain log file as well (optional)
#SUMMARY_LOG="Output/precheck_$(hostname).log"
SUMMARY_LOG="$PRECHECK_OUTDIR/precheck_$(hostname).log"
{
echo "=============== Precheck Results ======================="
echo "Required folders exist. [OK]"
echo "Network Connectivity          : $NET_RESULT"
echo "OS Detected                   : $OS_NAME ($OS_VERSION)"
echo "Compatible Target             : $COMPAT_OS"
echo "Hostname                      : $HOST"
echo "IP address                    : $IP"
echo "CPU Model                     : $CPU"
echo "CPU Cores                     : $CORES"
echo "RAM                           : $MEM"
echo "Disk                          : $DISK"
echo "System Time                   : $SYS_TIME"
echo "Timezone                      : $TIMEZONE"
echo "Admin access for Sputnik      : $ADMIN_STATUS"
echo "Admin access for Titan        : $TITAN_ADMIN_STATUS"
echo "Local Log                     : $LOCAL_LOG_MSG"
echo "EDR Detection                  : $EDR_STATUS$EDR_DETAIL_MSG"
echo "======================================================="
} > "$SUMMARY_LOG"
echo "Summary log saved at: $SUMMARY_LOG"


# Hand-off to package installer if present
if [[ -f Installpackage.sh ]]; then
    echo "[+] Now Installing Required Packages for simulation..."
    bash Installpackage.sh
else
    echo "[-] Installpackage.sh not found, skipping package installation."
fi



