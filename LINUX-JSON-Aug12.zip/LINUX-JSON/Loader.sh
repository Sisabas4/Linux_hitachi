#!/bin/bash

# Requirements: jq, wkhtmltopdf
# Trap every command and log it for JSON-based execution

JSON_FILE="$1"
TEMPLATE="Template/report_template.html"
SUMMARY_DIR="SummaryReport"
OUTPUT_DIR="Output"

if [[ -z "$JSON_FILE" ]]; then
    echo "No JSON file specified!"
    exit 1
fi

if [[ ! -f "$JSON_FILE" ]]; then
    echo "JSON file '$JSON_FILE' not found!"
    exit 1
fi

if [[ ! -f "$TEMPLATE" ]]; then
    echo "Template file '$TEMPLATE' not found!"
    exit 1
fi

USER_NAME=$(whoami)
TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

BASENAME=$(basename "$JSON_FILE" .json)

# Normalize output folder and report title based on BASENAME
case "$BASENAME" in
    Discovery_*|Discovery) OUT_FOLDER="Discovery" ;;
    Execution_*|Execution) OUT_FOLDER="Execution" ;;
    Exfiltration_*|Exfiltration) OUT_FOLDER="Exfiltration" ;;
    Defense_Evasion_*|Defense_Evasion) OUT_FOLDER="Defense_Evasion" ;;
    Persistence_*|Persistence) OUT_FOLDER="Persistence" ;;
    Privilege_Escalation_*|Privilege_Escalation) OUT_FOLDER="Privilege_Escalation" ;;
    Collection_*|Collection) OUT_FOLDER="Collection" ;;
    Impact_*|Impact) OUT_FOLDER="Impact" ;;
    Log_collect_*|Log_collect) OUT_FOLDER="Log_collect" ;;
    Cleanup_*|Cleanup) OUT_FOLDER="Cleanup" ;;
    Summary_Report_*|Summary_Report) OUT_FOLDER="Summary_Report" ;;
    *) OUT_FOLDER="$BASENAME" ;;
esac

REPORT_TITLE="${OUT_FOLDER^} Report"

TABLE_ROWS=""
TOTAL=0
SUCCESS=0
FAILURE=0

COUNT=$(jq '.commands | length' "$JSON_FILE")

TACTIC_DIR="$OUTPUT_DIR/$OUT_FOLDER"
mkdir -p "$TACTIC_DIR"

echo
echo "Running : $REPORT_TITLE"
echo

for (( i=0; i<COUNT; i++ )); do
    TACTIC_ID=$(jq -r ".commands[$i].tactic_id" "$JSON_FILE")
    TECHNIQUE=$(jq -r ".commands[$i].technique" "$JSON_FILE")
    CMD=$(jq -r ".commands[$i].command" "$JSON_FILE")

    echo "[+] Tactic ID   : $TACTIC_ID"
    echo "[+] Technique   : $TECHNIQUE"
    echo "[+] Command     :"
    echo -e "$CMD"

    OUTPUT_FILE="$TACTIC_DIR/${BASENAME}_${TACTIC_ID}.txt"

    # Add logging trap silently before executing the command
    LOGGER_SETUP='export LOG_FILE="/var/log/commands.log"; trap '\''logger -p local1.notice -t "[bash] '"$USER"'" "$BASH_COMMAND"'\'' DEBUG;'
    FULL_CMD="${LOGGER_SETUP}${CMD}"

    OUTPUT=$(bash -c "$FULL_CMD" 2>&1)
    STATUS=$?
    TOTAL=$((TOTAL + 1))

    if [[ $STATUS -eq 0 ]]; then
        STATUS_STR="Success"
        SUCCESS=$((SUCCESS + 1))
        echo "[+] Success"
        {
            echo "[+] Tactic ID   : $TACTIC_ID"
            echo "[+] Technique   : $TECHNIQUE"
            echo "[+] Command     :"
            echo -e "$CMD"
            echo "[+] Success"
            echo "----- OUTPUT START -----"
            echo "$OUTPUT"
            echo "----- OUTPUT END -----"
        } > "$OUTPUT_FILE"
    else
        STATUS_STR="Failure"
        FAILURE=$((FAILURE + 1))
        echo "[+] Failure"
        {
            echo "[+] Tactic ID   : $TACTIC_ID"
            echo "[+] Technique   : $TECHNIQUE"
            echo "[+] Command     :"
            echo -e "$CMD"
            echo "[+] Failure"
            echo "----- ERROR OUTPUT START -----"
            echo "$OUTPUT"
            echo "----- ERROR OUTPUT END -----"
        } > "$OUTPUT_FILE"
    fi

    # Add to HTML report rows, escape < for HTML validity
    TABLE_ROWS+="<tr>
<td>${TACTIC_ID}</td>
<td>${TECHNIQUE}</td>
<td><pre>${CMD//</&lt;}</pre></td>
<td>${STATUS_STR}</td>
</tr>
"
    echo
done

# Generate HTML report
OUTPUT_HTML="$SUMMARY_DIR/${BASENAME}_report.html"
OUTPUT_PDF="$SUMMARY_DIR/${BASENAME}_report.pdf"
mkdir -p "$SUMMARY_DIR"

HTML_CONTENT=$(<"$TEMPLATE")
HTML_CONTENT="${HTML_CONTENT//\{\{report_title\}\}/$REPORT_TITLE}"
HTML_CONTENT="${HTML_CONTENT//\{\{tactic\}\}/$OUT_FOLDER}"
HTML_CONTENT="${HTML_CONTENT//\{\{user\}\}/$USER_NAME}"
HTML_CONTENT="${HTML_CONTENT//\{\{timestamp\}\}/$TIMESTAMP}"
HTML_CONTENT="${HTML_CONTENT//\{\{table_rows\}\}/$TABLE_ROWS}"
HTML_CONTENT="${HTML_CONTENT//\{\{total\}\}/$TOTAL}"
HTML_CONTENT="${HTML_CONTENT//\{\{success\}\}/$SUCCESS}"
HTML_CONTENT="${HTML_CONTENT//\{\{failure\}\}/$FAILURE}"

echo "$HTML_CONTENT" > "$OUTPUT_HTML"

wkhtmltopdf "$OUTPUT_HTML" "$OUTPUT_PDF" >/dev/null 2>&1

rm -f "$OUTPUT_HTML"

echo "PDF report generated at: $OUTPUT_PDF"

