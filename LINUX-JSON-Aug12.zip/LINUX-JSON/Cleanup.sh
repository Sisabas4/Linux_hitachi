#!/bin/bash

#=====================
echo "[+] Deleting User created for Simulation"
bash Cleanup/Precheck/precheck_userdel.sh

echo ""
echo ""
echo "[+] Uninstalling Packages.."
bash Cleanup/Precheck/uninstall_packages.sh

echo ""
#=====================
echo ""
echo "[+] Cleanup Discovery.. "
#bash Cleanup/
echo ""
#=====================
echo ""
echo "[+] Cleanup Execution.. "
bash Cleanup/Cleanup_Execution.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup Defense Evasion"
bash Cleanup/Cleanup_DefenseEvasion.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup Persistence.. "
bash Cleanup/Cleanup_persistence.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup PrivilegeEscalation.. "
bash Cleanup/Cleanup_PrivilegeEscalation.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup Collection.. "
bash Cleanup/Cleanup_Collection.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup Impact.. "
bash Cleanup/Cleanup_Impact.sh
echo ""
#=====================
echo ""
echo "[+] Cleanup Exfiltration.. "
echo $PWD
bash Cleanup/Cleanup_Exfiltration.sh
echo ""
