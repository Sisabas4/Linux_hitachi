#!/bin/bash

#=====================================================================================================
# Detect distro and version
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
    VERSION=$VERSION_ID
else
    echo "Cannot determine the Linux distribution."
    exit 1
fi
echo "Detected distro: $DISTRO, version: $VERSION"

# Get Architecture
ARCH=$(uname -m)
if [ "$ARCH" = "x86_64" ]; then
    ARCH="amd64"
fi
echo "Architecture: $ARCH"
#====================================================================================================

#INSTALL MEGACMD


# Ubuntu logic
if [ "$DISTRO" = "ubuntu" ]; then
    case $VERSION in
        "25.04"|"24.10"|"24.04"|"22.04"|"20.10"|"20.04"|"19.10"|"18.04")
            FILENAME="megacmd-xUbuntu_${VERSION}_${ARCH}.deb"
            PACKAGE_URL="https://mega.nz/linux/repo/xUbuntu_${VERSION}/${ARCH}/${FILENAME}"
            if [ -f "$FILENAME" ]; then
                echo "File $FILENAME already exists. Skipping download."
            else
                echo "Downloading MEGAcmd for Ubuntu $VERSION..."
                wget "$PACKAGE_URL" -O "$FILENAME"
                if [ $? -ne 0 ]; then
                    echo "Download failed for version $VERSION."
                    exit 1
                fi
            fi
            echo "Installing MEGAcmd..."
            sudo apt install ./"$FILENAME"
            ;;
        *)
            echo "Unsupported Ubuntu version: $VERSION"
            exit 1
            ;;
    esac

# CentOS logic
elif [ "$DISTRO" = "centos" ]; then
    case $VERSION in
        "7")
            FILENAME="megacmd-1.6.3-1.1.x86_64.rpm"
            PACKAGE_URL="https://mega.nz/linux/repo/CentOS_7/x86_64/$FILENAME"
            ;;
        "8")
            FILENAME="megacmd-1.6.1-3.1.x86_64.rpm"
            PACKAGE_URL="https://mega.nz/linux/repo/CentOS_8/x86_64/$FILENAME"
            ;;
        *)
            echo "Unsupported CentOS version: $VERSION"
            exit 1
            ;;
    esac
    if [ -f "$FILENAME" ]; then
        echo "File $FILENAME already exists. Skipping download."
    else
        echo "Downloading MEGAcmd for CentOS $VERSION..."
        wget "$PACKAGE_URL" -O "$FILENAME"
        if [ $? -ne 0 ]; then
            echo "Download failed for CentOS $VERSION."
            exit 1
        fi
    fi
    echo "Installing MEGAcmd..."
    sudo yum install -y ./"$FILENAME"

# Red Hat logic
elif [[ "$DISTRO" == "rhel" || "$DISTRO" == "redhat" ]]; then
    case $VERSION in
        "8")
            FILENAME="megacmd-1.2.0-1.1.x86_64.rpm"
            PACKAGE_URL="https://mega.nz/linux/repo/RHEL_8/x86_64/$FILENAME"
            ;;
        *)
            echo "Unsupported Red Hat version: $VERSION"
            exit 1
            ;;
    esac
    if [ -f "$FILENAME" ]; then
        echo "File $FILENAME already exists. Skipping download."
    else
        echo "Downloading MEGAcmd for RHEL $VERSION..."
        wget "$PACKAGE_URL" -O "$FILENAME"
        if [ $? -ne 0 ]; then
            echo "Download failed for RHEL $VERSION."
            exit 1
        fi
    fi
    echo "Installing MEGAcmd..."
    sudo yum install -y ./"$FILENAME"

else
    echo "Unsupported Linux distribution: $DISTRO"
    exit 1
fi
#====================================================================================================
