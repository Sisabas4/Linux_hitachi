#!/bin/bash

# Technique Info
technique_id="T1543.002"
technique_name="Create or Modify System Process"
output_dir="./Output/Persistence"
output_file="${output_dir}/${technique_id}_Persistence.txt"

# Ensure output directory exists
mkdir -p "$output_dir"

# Create a fake service unit file for sisa-test
service_name="sisa-test"
service_path="/etc/systemd/system/${service_name}.service"

echo "[Unit]
Description=Fake SISA Test Service

[Service]
ExecStart=/bin/true

[Install]
WantedBy=multi-user.target" | sudo tee "$service_path" > /dev/null

# Set correct permissions
sudo chmod 644 "$service_path"

# Reload systemd to recognize new service
echo "Reloading systemd daemon..." | tee -a "$output_file"
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

# Enable the service
echo "Enabling $service_name..." | tee -a "$output_file"
sudo systemctl enable "$service_name" 2>&1 | tee -a "$output_file"

# Start the service
echo "Starting $service_name..." | tee -a "$output_file"
sudo systemctl start "$service_name" 2>&1 | tee -a "$output_file"

# Stop the service
echo "Stopping $service_name..." | tee -a "$output_file"
sudo systemctl stop "$service_name" 2>&1 | tee -a "$output_file"

# Disable the service
echo "Disabling $service_name..." | tee -a "$output_file"
sudo systemctl disable "$service_name" 2>&1 | tee -a "$output_file"

# Clean up service file if needed (comment this out to persist)
# sudo rm "$service_path"
# sudo systemctl daemon-reload

echo "[$technique_id] $technique_name simulation complete." | tee -a "$output_file"
