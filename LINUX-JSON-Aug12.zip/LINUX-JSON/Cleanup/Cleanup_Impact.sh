#!/bin/sh

# List of files to check and remove
FILES="/tmp/new_execve_entry.log /tmp/audit_copy.log"

for FILE in $FILES; do
  if [ -e "$FILE" ]; then
    echo "[+] Removing $FILE"
    sudo rm -f "$FILE"
  else
    echo "[-] $FILE does not exist"
  fi
done
