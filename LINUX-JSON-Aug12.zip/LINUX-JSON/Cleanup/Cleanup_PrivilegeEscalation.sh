#!/bin/sh

# List of files to check and remove
FILES="/tmp/hello /tmp/CBinary.c /tmp/SetUIDFile /tmp/SetGIDFile /tmp/SetUID.c /tmp/SetUID /tmp/FileUID"

for FILE in $FILES; do
  if [ -e "$FILE" ]; then
    echo "[+] Removing $FILE"
    sudo rm -f "$FILE"
  else
    echo "[-] $FILE does not exist"
  fi
done

PRELOAD_FILE="/etc/ld.so.preload"
TARGET_LINE="/tmp/LdPreload.so"

if [ -f "$PRELOAD_FILE" ]; then
    line_count=$(wc -l < "$PRELOAD_FILE")
    content=$(cat "$PRELOAD_FILE" | tr -d '[:space:]')

    if [ "$line_count" -eq 1 ] && [ "$content" == "$TARGET_LINE" ]; then
        echo "Safe to remove $PRELOAD_FILE"
        sudo rm -f "$PRELOAD_FILE"
        echo "Removed $PRELOAD_FILE"
    else
        echo "$PRELOAD_FILE exists but is not safe to remove (multiple or different entries)"
    fi
else
    echo "$PRELOAD_FILE does not exist."
fi

sudo rm -f $PRELOAD_FILE
sudo rm -f $TARGET_FILE
