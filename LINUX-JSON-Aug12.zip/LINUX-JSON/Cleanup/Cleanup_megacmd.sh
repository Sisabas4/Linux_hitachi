#!/bin/bash

echo "Uninstalling MEGAcmd..."

# Remove the MEGAcmd package
sudo apt remove -y megacmd

# Optionally purge configuration files
read -p "Do you want to purge MEGAcmd config files? (y/N): " PURGE
if [[ "$PURGE" =~ ^[Yy]$ ]]; then
    sudo apt purge -y megacmd
fi

# Autoremove unused dependencies
sudo apt autoremove -y

# Optionally remove user data
read -p "Do you want to delete MEGAcmd user data in ~/.mega and ~/.megacmd? (y/N): " REMOVE_DATA
if [[ "$REMOVE_DATA" =~ ^[Yy]$ ]]; then
    rm -rf ~/.mega ~/.megacmd
    echo "User data removed."
fi

echo "MEGAcmd has been uninstalled."
