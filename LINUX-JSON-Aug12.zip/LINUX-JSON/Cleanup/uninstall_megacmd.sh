#!/bin/bash

echo "Uninstalling MEGAcmd..."

# Detect distro family
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_FAMILY="$ID"
    OS_PRETTY="$PRETTY_NAME"
else
    echo "Cannot detect operating system (no /etc/os-release)."
    exit 1
fi

echo "Detected OS: $OS_PRETTY"

UNINSTALL_CMD=""
PURGE_CMD=""
AUTOREMOVE_CMD=""

case "$OS_FAMILY" in
    ubuntu|debian)
        UNINSTALL_CMD="sudo apt remove -y megacmd"
        PURGE_CMD="sudo apt purge -y megacmd"
        AUTOREMOVE_CMD="sudo apt autoremove -y"
        ;;
    rhel|centos|fedora|rocky|almalinux)
        if command -v dnf >/dev/null 2>&1; then
            UNINSTALL_CMD="sudo dnf remove -y megacmd"
            PURGE_CMD=""  # dnf doesn't have purge; configs may remain
            AUTOREMOVE_CMD="sudo dnf autoremove -y"
        else
            UNINSTALL_CMD="sudo yum remove -y megacmd"
            AUTOREMOVE_CMD="sudo yum autoremove -y"
        fi
        ;;
    *)
        echo "Unsupported OS family: $OS_FAMILY"
        exit 2
        ;;
esac

echo "Running: $UNINSTALL_CMD"
eval "$UNINSTALL_CMD"

if [ -n "$PURGE_CMD" ]; then
    read -p "Do you want to purge MEGAcmd config files? (y/N): " PURGE
    if [[ "$PURGE" =~ ^[Yy]$ ]]; then
        echo "Running: $PURGE_CMD"
        eval "$PURGE_CMD"
    fi
fi

echo "Running: $AUTOREMOVE_CMD"
eval "$AUTOREMOVE_CMD"

# Optionally remove user data
read -p "Do you want to delete MEGAcmd user data in ~/.mega and ~/.megacmd? (y/N): " REMOVE_DATA
if [[ "$REMOVE_DATA" =~ ^[Yy]$ ]]; then
    rm -rf ~/.mega ~/.megacmd
    echo "User data removed."
fi

echo "MEGAcmd has been uninstalled."
