#!/bin/bash

# Check if response JSON file exists
if [[ ! -f Cleanup/gofile_response.json ]]; then
  echo "gofile_response.json not found!"
  exit 1
fi

# Extract guestToken and contentId from JSON using jq
guestToken=$(jq -r '.data.guestToken' Cleanup/gofile_response.json)
contentId=$(jq -r '.data.id' Cleanup/gofile_response.json)

if [[ -z "$guestToken" || "$guestToken" == "null" ]]; then
  echo "guestToken not found in JSON"
  exit 1
fi

if [[ -z "$contentId" || "$contentId" == "null" ]]; then
  echo "content ID not found in JSON"
  exit 1
fi

echo "Deleting content ID: $contentId with guest token..."

# Perform the DELETE request
curl -X DELETE "https://api.gofile.io/contents" \
  -H "Authorization: Bearer $guestToken" \
  -H "Content-Type: application/json" \
  -d "{\"contentsId\":\"$contentId\"}"

echo -e "\nDelete request sent."
