#!/bin/bash

echo "[*] Starting persistence cleanup for T1098.004, T1543.002, T1037.004, T1546.004, T1136.001, T1053.002, T1053.003"

# ==== [ T1098.004 ] Cleanup SSH Authorized Keys ====
echo "[+] Cleaning T1098.004 - SSH Authorized Keys"
AUTHORIZED_KEY="$HOME/.ssh/authorized_keys"
[ -f "$AUTHORIZED_KEY" ] && sed -i '/# T1098.004/d' "$AUTHORIZED_KEY"

# ==== [ T1543.002 ] Cleanup System Process ====
echo "[+] Cleaning T1543.002 - Create/Modify System Process"
rm -f /etc/systemd/system/sisa-persist.service
rm -f /etc/init.d/sisa-persist
systemctl daemon-reexec 2>/dev/null
systemctl daemon-reload 2>/dev/null

# ==== [ T1037.004 ] Cleanup Boot or Logon Initialization Scripts ====
echo "[+] Cleaning T1037.004 - Boot/Logon Initialization Scripts"
rm -f /etc/profile.d/sisa.sh /etc/profile.d/sisa*
sed -i '/# T1037.004/d' ~/.bash_profile ~/.bashrc ~/.profile 2>/dev/null

# ==== [ T1546.004 ] Cleanup Event Triggered Execution ====
echo "[+] Cleaning T1546.004 - Event Triggered Execution"
sed -i '/T1546.004/d' ~/.bash_profile ~/.bashrc ~/.profile 2>/dev/null
sudo sed -i '/T1546.004/d' /etc/profile /etc/profile.d/bash_completion.sh 2>/dev/null
sudo userdel -r art 2>/dev/null
rm -f /tmp/T1546.004
rm -f Output/Persistence_Deb/T1546.004_Persistence.txt

# ==== [ T1136.001 ] Cleanup Created User clown ====
echo "[+] Cleaning T1136.001 - Remove user clown"
sudo userdel -r clown 2>/dev/null

# ==== [ T1053.002 ] Cleanup 'at' jobs ====
echo "[+] Cleaning T1053.002 - Scheduled Task/Job: At"
atrm $(atq | awk '{print $1}') 2>/dev/null
rm -f Output/Persistence_Deb/T1053.002_Execution.txt

# ==== [ T1053.003 ] Cleanup 'cron' jobs ====
echo "[+] Cleaning T1053.003 - Scheduled Task/Job: Cron"
CRON_FILE="/tmp/persistevil"
crontab -l | grep -v '/tmp/evil.sh' | crontab -
sudo rm -f /etc/cron.daily/persistevil \
            /etc/cron.hourly/persistevil \
            /etc/cron.weekly/persistevil \
            /etc/cron.monthly/persistevil \
            /etc/cron.d/persistevil \
            /var/spool/cron/crontabs/persistevil \
            /var/spool/cron/persistevil 2>/dev/null
rm -f /tmp/evil.sh /tmp/SISA.log "$CRON_FILE" /tmp/notevil
echo "[*] Starting cleanup for T1037.004 - Boot or Logon Initialization Scripts"

# === Cleanup rc.common ===
function rc_common_cleanup {
    echo "[+] Cleaning up /etc/rc.common"
    local file='/etc/rc.common'
    local backup='/etc/rc.common.original'

    if [ -f "$backup" ]; then
        sudo cp "$backup" "$file" && sudo rm "$backup"
        echo "[✓] Restored original rc.common from backup"
    else
        sudo rm -f "$file"
        echo "[✓] Deleted rc.common (no backup found)"
    fi
}

# === Cleanup rc.local ===
function rc_local_cleanup {
    echo "[+] Cleaning up /etc/rc.local"
    local file='/etc/rc.local'
    local backup='/etc/rc.local.original'

    if [ -f "$backup" ]; then
        sudo cp "$backup" "$file" && sudo rm "$backup"
        echo "[✓] Restored original rc.local from backup"
    else
        sudo rm -f "$file"
        echo "[✓] Deleted rc.local (no backup found)"
    fi
}

# === Clean generated output file ===
function clean_output {
    echo "[+] Cleaning output directory and logs"
    rm -f Linux_output/Persistence/T1037.004_Persistence.txt
    rmdir --ignore-fail-on-non-empty Linux_output/Persistence 2>/dev/null
    echo "[✓] Output logs cleaned"
}

# === Distribution Awareness (optional logging) ===
function log_distro {
    DISTRO=$(grep '^ID=' /etc/os-release | cut -d= -f2 | tr -d '"')
    echo "[*] Detected Distribution: $DISTRO"
}

# === Run Cleanup ===
log_distro
rc_common_cleanup
rc_local_cleanup
clean_output

echo "[✔] Cleanup for T1037.004 completed successfully"
# === Configurations ===
OUTPUT_FILE="./Linux_output/Persistence/T1098.004_Persistence.txt"
ATTACKER_KEY="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCfakeattackersshkeycomment attacker@redteam"

# === Detect target user (default to current user) ===
TARGET_USER=$(whoami)
USER_HOME=$(eval echo "~$TARGET_USER")
AUTHORIZED_KEYS_FILE="$USER_HOME/.ssh/authorized_keys"

# === Begin Cleanup ===
echo "==========================================================" | tee -a "$OUTPUT_FILE"
echo "[*] Starting Cleanup for T1098.004 - SSH Authorized Keys" | tee -a "$OUTPUT_FILE"
echo "==========================================================" | tee -a "$OUTPUT_FILE"

if [ ! -f "$AUTHORIZED_KEYS_FILE" ]; then
    echo "[!] No authorized_keys file found for user '$TARGET_USER'" | tee -a "$OUTPUT_FILE"
    exit 0
fi

# === Backup the current authorized_keys file ===
cp "$AUTHORIZED_KEYS_FILE" "$AUTHORIZED_KEYS_FILE.bak"
echo "[+] Backup created: $AUTHORIZED_KEYS_FILE.bak" | tee -a "$OUTPUT_FILE"

# === Remove the attacker key ===
grep -vxF "$ATTACKER_KEY" "$AUTHORIZED_KEYS_FILE" > "${AUTHORIZED_KEYS_FILE}.tmp" && mv "${AUTHORIZED_KEYS_FILE}.tmp" "$AUTHORIZED_KEYS_FILE"
chmod 600 "$AUTHORIZED_KEYS_FILE"
chown "$TARGET_USER:$TARGET_USER" "$AUTHORIZED_KEYS_FILE"

if grep -qF "$ATTACKER_KEY" "$AUTHORIZED_KEYS_FILE"; then
    echo "[✗] Failed to remove attacker SSH key from $AUTHORIZED_KEYS_FILE" | tee -a "$OUTPUT_FILE"
else
    echo "[✓] Attacker SSH key removed from $AUTHORIZED_KEYS_FILE" | tee -a "$OUTPUT_FILE"
fi

# === Clean output directory if empty ===
rmdir --ignore-fail-on-non-empty ./Linux_output/Persistence 2>/dev/null

echo "[✔] Cleanup for T1098.004 completed successfully." | tee -a "$OUTPUT_FILE"

# Technique Info
technique_id="T1543.002"
technique_name="Create or Modify System Process"
output_dir="./Output/Persistence_Deb"
output_file="${output_dir}/${technique_id}_Cleanup.txt"

# Service Details
service_name="sisa-test"
service_path="/etc/systemd/system/${service_name}.service"

# Ensure output directory exists
mkdir -p "$output_dir"

echo "==========================================================" | tee "$output_file"
echo "[*] Starting Cleanup for $technique_id - $technique_name" | tee -a "$output_file"
echo "==========================================================" | tee -a "$output_file"

# Stop service if running
if systemctl is-active --quiet "$service_name"; then
    echo "[+] Stopping $service_name service..." | tee -a "$output_file"
    sudo systemctl stop "$service_name" 2>&1 | tee -a "$output_file"
else
    echo "[-] Service $service_name not running." | tee -a "$output_file"
fi

# Disable the service if enabled
if systemctl is-enabled --quiet "$service_name"; then
    echo "[+] Disabling $service_name service..." | tee -a "$output_file"
    sudo systemctl disable "$service_name" 2>&1 | tee -a "$output_file"
else
    echo "[-] Service $service_name not enabled." | tee -a "$output_file"
fi

# Remove the service file
if [ -f "$service_path" ]; then
    echo "[+] Removing $service_path..." | tee -a "$output_file"
    sudo rm -f "$service_path"
else
    echo "[-] Service file not found at $service_path" | tee -a "$output_file"
fi

# Reload systemd daemon
echo "[*] Reloading systemd daemon..." | tee -a "$output_file"
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

echo "[✔] Cleanup for $technique_id complete." | tee -a "$output_file"

# === Clean Directory ===
rmdir ./Output/Persistence_Deb 2>/dev/null

echo "[✔] Cleanup completed successfully."
