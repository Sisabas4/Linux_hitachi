#!/bin/bash

INPUT_FILE="Cleanup/Precheck/Touninstall.txt"
PACKAGES_TO_REMOVE=()

# Detect and set package removal command
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_ID=$ID
else
    echo "[!] Cannot determine OS. /etc/os-release not found."
    exit 1
fi

# Determine correct remove command
case "$OS_ID" in
    ubuntu|debian|kali)
        PKG_REMOVE="apt remove -y"
        ;;
    amzn|rhel|centos|fedora)
        if command -v dnf &>/dev/null; then
            PKG_REMOVE="dnf remove -y"
        else
            PKG_REMOVE="yum remove -y"
        fi
        ;;
    *)
        echo "[!] Unsupported or unknown OS: $OS_ID"
        exit 1
esac

echo $PWD
if [ ! -f "$INPUT_FILE" ]; then
    echo "[!] File $INPUT_FILE not found. Please run the install script first."
    exit 1
fi

# Parse the file for packages marked "Not Installed"
while read -r line; do
    [[ "$line" =~ ^Package.*|^-+|^$ ]] && continue

    pkg=$(echo "$line" | awk -F '|' '{print $1}' | xargs)
    status=$(echo "$line" | awk -F '|' '{print $2}' | xargs)

    if [ "$status" = "Not Installed" ]; then
        PACKAGES_TO_REMOVE+=("$pkg")
    fi
done < "$INPUT_FILE"

if [ ${#PACKAGES_TO_REMOVE[@]} -eq 0 ]; then
    echo "[*] No packages to uninstall (none were missing before)."
    exit 0
fi

echo "[*] Packages to uninstall (only those that were missing before):"
for p in "${PACKAGES_TO_REMOVE[@]}"; do
    echo " - $p"
done

read -p "Do you want to uninstall these packages? (y/n): " choice
if [[ ! "$choice" =~ ^[Yy]$ ]]; then
    echo "Uninstallation aborted by user."
    exit 0
fi

echo "[*] Uninstalling packages..."
for pkg in "${PACKAGES_TO_REMOVE[@]}"; do
    echo " - Uninstalling $pkg"
    if ! sudo $PKG_REMOVE "$pkg" > /dev/null 2>&1; then
        echo "[ERROR] Failed to uninstall $pkg"
    else
        echo "    $pkg removed"
    fi
done

echo "[*] Uninstallation complete."

