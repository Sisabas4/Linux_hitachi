#!/bin/bash

for uname in Sputnik Titan; do
    if id "$uname" &>/dev/null; then
        userdel -r "$uname" &>/dev/null
        echo "User $uname deleted."
    else
        echo "User $uname does not exist."
    fi
done
