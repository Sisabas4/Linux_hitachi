#!/bin/bash

echo "[+] Uninstalling Megacmd..."
sudo bash Cleanup/uninstall_megacmd.sh

echo "[+] Deleting Gofile PublicLink.."
sudo bash Cleanup/gofile_cleanup.sh

