#!/bin/bash

echo "[*] Cleaning up T1014 libprocesshider dynamic linker injection..."
LIBHIDE="/usr/local/lib/libprocesshider.so"
EVIL_SCRIPT="/usr/local/bin/evil_script.py"
LD_PRELOAD="/etc/ld.so.preload"

# Remove the library path from ld.so.preload
sudo sed -i "\:^${LIBHIDE}:d" "${LD_PRELOAD}"

# Remove files
sudo rm -f "${LIBHIDE}" "${EVIL_SCRIPT}"

# Reload dynamic linker
sudo depmod -a

# Remove temporary directories
sudo rm -rf /tmp/atomic libprocesshider-*

echo "[+] T1014.3 cleanup complete."

echo
echo "[*] Cleaning up T1014 Diamorphine LKM rootkit..."

ROOTKIT="diamorphine"
KO_PATH="/lib/modules/$(uname -r)/${ROOTKIT}.ko"
TMP_DIR="/tmp/atomic"

# Unload the kernel module if still loaded
sudo modprobe -r "${ROOTKIT}"

# Remove kernel object and temp dir
sudo rm -f "${KO_PATH}"
sudo rm -rf "${TMP_DIR}" Diamorphine-*

# Refresh module dependency
sudo depmod -a

echo "[+] T1014.4 cleanup complete."
