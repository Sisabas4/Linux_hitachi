#!/bin/bash

echo "[*] Cleanup started for Collection & Archiving Simulation Artifacts"

# === T1074.001: Local Data Staging ===
echo "[+] Cleaning T1074.001 - Local Data Staging"
rm -rf ./Output/Collection_Deb/T1074.001_Collection.txt 2>/dev/null
rm -rf ./Output/Collection_Deb 2>/dev/null

# === T1113: Screen Capture ===
echo "[+] Cleaning T1113 - Screen Capture"
rm -rf ./Output/Collection_Deb/T1113_Collection_screenshots 2>/dev/null

# === T1560.002: Archive Collected Data ===
echo "[+] Cleaning T1560.002 - Archive via Library"
rm -f /tmp/sisa_test1.py /tmp/sisa_test2.py /tmp/sisa_test3.py /tmp/sisa_test4.py
rm -f /tmp/passwd.gz /tmp/passwd.bz2 /tmp/passwd.zip /tmp/passwd.tar.gz
rm -f ./Output/Collection_Deb/T1560.002_Collection.txt 2>/dev/null

# Final cleanup if folder is empty
[ -d "./Output/Collection_Deb" ] && rmdir ./Output/Collection_Deb 2>/dev/null

echo "[✔] Cleanup complete."
