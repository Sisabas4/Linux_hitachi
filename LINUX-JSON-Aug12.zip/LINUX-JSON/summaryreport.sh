#!/bin/bash

PDFDIR="SummaryReport"
OUTPUT="ExecutiveSummaryReport.pdf"

ORDER=(
    Discovery
    Execution
    Defense_Evasion
    Persistence
    Privilege_Escalation
    Collection
    Impact
    Exfiltration
)

INPUTS=""
for base in "${ORDER[@]}"; do
    # Find the first matching file for each section
    file=$(ls "${PDFDIR}/${base}"*.pdf 2>/dev/null | sort | head -n 1)
    if [[ -f "$file" ]]; then
        INPUTS="$INPUTS $file"
    else
        echo "Warning: No file for $base found! Skipping."
    fi
done

if [[ -z "$INPUTS" ]]; then
    echo "No input PDF files found. Aborting!"
    exit 1
fi

# Merge using pdfunite
pdfunite $INPUTS "$PDFDIR/$OUTPUT"

if [[ $? -eq 0 ]]; then
    echo "Merged PDF created at: $PDFDIR/$OUTPUT"
else
    echo "Merging failed!"
    exit 1
fi
